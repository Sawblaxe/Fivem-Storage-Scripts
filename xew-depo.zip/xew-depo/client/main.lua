local QBCore = nil
local ESX = nil
local Framework = nil
local PlayerData = {}
local StoragePeds = {}
local isStorageOpen = false
local Locales = Locales or {}

-- Get Locale Text
function _U(str, ...)
    if Locales[Config.Locale] ~= nil then
        if Locales[Config.Locale][str] ~= nil then
            return string.format(Locales[Config.Locale][str], ...)
        else
            return 'Translation [' .. Config.Locale .. '][' .. str .. '] does not exist'
        end
    else
        return 'Locale [' .. Config.Locale .. '] does not exist'
    end
end

-- Framework Detection
CreateThread(function()
    -- Framework yüklenmesini bekle
    while not NetworkIsPlayerActive(PlayerId()) do
        Wait(100)
    end
    
    if Config.Framework == 'auto' then
        if GetResourceState('es_extended') == 'started' then
            Config.Framework = 'esx'
        elseif GetResourceState('qb-core') == 'started' then
            -- QB Version Detection
            local qbVersion = GetResourceMetadata('qb-core', 'version', 0)
            if qbVersion and tonumber(string.sub(qbVersion, 1, 1)) >= 2 then
                Config.Framework = 'newqb'
            else
                Config.Framework = 'oldqb'
            end
        end
    end

    -- Framework Initialize
    if Config.Framework == 'esx' then
        ESX = exports['es_extended']:getSharedObject()
        Framework = ESX
        
        RegisterNetEvent('esx:playerLoaded')
        AddEventHandler('esx:playerLoaded', function(xPlayer)
            PlayerData = xPlayer
        end)
        
        RegisterNetEvent('esx:setJob')
        AddEventHandler('esx:setJob', function(job)
            PlayerData.job = job
        end)
        
    elseif Config.Framework == 'newqb' then
        QBCore = exports['qb-core']:GetCoreObject()
        Framework = QBCore
        
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
            PlayerData = QBCore.Functions.GetPlayerData()
        end)
        
        RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
            PlayerData.job = JobInfo
        end)
        
    elseif Config.Framework == 'oldqb' then
        while QBCore == nil do
            TriggerEvent('QBCore:GetObject', function(obj) QBCore = obj end)
            Wait(200)
        end
        Framework = QBCore
        
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded')
        AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
            PlayerData = QBCore.Functions.GetPlayerData()
        end)
        
        RegisterNetEvent('QBCore:Client:OnJobUpdate')
        AddEventHandler('QBCore:Client:OnJobUpdate', function(JobInfo)
            PlayerData.job = JobInfo
        end)
    end
    
    -- Auto detect systems
    DetectTargetSystem()
    DetectInventorySystem()
    
    -- Framework yüklendikten sonra ped'leri spawn et
    Wait(2000)
    SpawnStoragePeds()
    
    -- Print startup messages
    Wait(1000)
    print('^2[Personal Storage]^7 Client başarıyla yüklendi!')
    print('^2[Personal Storage]^7 Framework: ^3' .. Config.Framework)
    print('^2[Personal Storage]^7 Inventory System: ^3' .. Config.InventorySystem)
    print('^2[Personal Storage]^7 Target System: ^3' .. (Config.UseTarget and Config.TargetSystem or 'Disabled'))
    print('^2[Personal Storage]^7 Language: ^3' .. Config.Locale)
    print('^2[Personal Storage]^7 Ped Model: ^3' .. Config.PedModel)
    print('^2[Personal Storage]^7 Storage Locations: ^3' .. #Config.StorageLocations)
end)

-- Target System Detection
function DetectTargetSystem()
    if Config.TargetSystem == 'auto' then
        if GetResourceState('qb-target') == 'started' then
            Config.TargetSystem = 'qb-target'
        elseif GetResourceState('ox_target') == 'started' then
            Config.TargetSystem = 'ox_target'
        else
            Config.UseTarget = false
        end
    end
end

-- Inventory System Detection
function DetectInventorySystem()
    if Config.InventorySystem == 'auto' then
        if GetResourceState('ox_inventory') == 'started' then
            Config.InventorySystem = 'ox_inventory'
        elseif GetResourceState('codem-inventory') == 'started' then
            Config.InventorySystem = 'codem-inventory'
        elseif GetResourceState('tgiann-inventory') == 'started' then
            Config.InventorySystem = 'tgiann-inventory'
        elseif GetResourceState('qb-inventory') == 'started' then
            Config.InventorySystem = 'qb-inventory'
        end
    end
end

-- Spawn Storage Peds
function SpawnStoragePeds()
    print('^3[Personal Storage]^7 Ped\'ler spawn ediliyor...')
    
    for i, location in pairs(Config.StorageLocations) do
        print('^3[Personal Storage]^7 Spawn ediliyor: ' .. location.name .. ' - ' .. location.coords.x .. ', ' .. location.coords.y .. ', ' .. location.coords.z)
        
        RequestModel(Config.PedModel)
        while not HasModelLoaded(Config.PedModel) do
            Wait(1)
        end
        
        local ped = CreatePed(4, Config.PedModel, location.coords.x, location.coords.y, location.coords.z - 1.0, location.coords.w, false, true)
        
        SetEntityHeading(ped, location.coords.w)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        
        -- Set ped scenario
        TaskStartScenarioInPlace(ped, Config.PedScenario, 0, true)
        
        StoragePeds[i] = {
            ped = ped,
            coords = location.coords,
            name = location.name
        }
        
        -- Target System Integration
        if Config.UseTarget then
            if Config.TargetSystem == 'qb-target' then
                exports['qb-target']:AddTargetEntity(ped, {
                    options = {
                        {
                            icon = "fas fa-box",
                            label = _U('target_label'),
                            action = function(entity)
                                OpenStorage(i)
                            end
                        }
                    },
                    distance = Config.InteractionDistance
                })
            elseif Config.TargetSystem == 'ox_target' then
                exports.ox_target:addLocalEntity({ped}, {
                    {
                        name = 'storage_' .. i,
                        label = _U('target_label'),
                        icon = 'fas fa-box',
                        distance = Config.InteractionDistance,
                        onSelect = function()
                            OpenStorage(i)
                        end
                    }
                })
            end
        end
    end
    
    print('^2[Personal Storage]^7 Tüm ped\'ler başarıyla spawn edildi! Toplam: ^3' .. #Config.StorageLocations)
end

-- Open Storage Function
function OpenStorage(storageId)
    -- Flag'i her zaman sıfırla
    isStorageOpen = false
    
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    TriggerServerEvent('personal-storage:server:openStorage', storageId, playerCoords)
end

-- Storage Events
RegisterNetEvent('personal-storage:client:openStorage')
AddEventHandler('personal-storage:client:openStorage', function(data)
    local storageId = data.storageId or data
    OpenStorage(storageId)
end)

RegisterNetEvent('personal-storage:client:openInventory')
AddEventHandler('personal-storage:client:openInventory', function(storageId)
    print('^3[Personal Storage]^7 Client received openInventory event for storage: ' .. storageId)
    
    isStorageOpen = true
    
    local identifier = nil
    if Config.Framework == 'esx' then
        local playerData = ESX.GetPlayerData()
        identifier = playerData and playerData.identifier
    elseif Config.Framework == 'newqb' or Config.Framework == 'oldqb' then
        local playerData = QBCore.Functions.GetPlayerData()
        identifier = playerData and playerData.citizenid
    end
    
    if not identifier then
        print('^1[Personal Storage]^7 No identifier found!')
        return
    end
    
    local stashName = 'personal_storage_' .. storageId .. '_' .. identifier
    print('^2[Personal Storage]^7 Opening stash: ' .. stashName)
    
    if Config.InventorySystem == 'ox_inventory' then
        print('^3[Personal Storage]^7 Using OX Inventory')
        exports.ox_inventory:openInventory('stash', stashName)
        
    elseif Config.InventorySystem == 'qb-inventory' then
        print('^3[Personal Storage]^7 Using QB Inventory')
        TriggerServerEvent("inventory:server:OpenInventory", "stash", stashName, {
            maxweight = Config.StorageWeight,
            slots = Config.StorageSlots,
        })
        TriggerEvent("inventory:client:SetCurrentStash", stashName)
        
    elseif Config.InventorySystem == 'codem-inventory' then
        print('^3[Personal Storage]^7 Using Codem Inventory')
        exports['codem-inventory']:OpenStash(stashName, Config.StorageSlots, Config.StorageWeight)
        
    elseif Config.InventorySystem == 'tgiann-inventory' then
        print('^3[Personal Storage]^7 Using TGiann Inventory')
        exports['tgiann-inventory']:OpenStash(stashName)
    else
        print('^1[Personal Storage]^7 Unknown inventory system: ' .. Config.InventorySystem)
    end
    
    -- Genel kapanma kontrolü
    CreateThread(function()
        Wait(5000) -- 5 saniye bekle
        isStorageOpen = false
        TriggerServerEvent('personal-storage:server:closeStorage', storageId)
    end)
    
    -- Notification
    if Config.Framework == 'esx' then
        if ESX then
            ESX.ShowNotification(_U('storage_opened'))
        end
    elseif Config.Framework == 'newqb' or Config.Framework == 'oldqb' then
        if QBCore then
            QBCore.Functions.Notify(_U('storage_opened'), 'success')
        end
    end
end)

RegisterNetEvent('personal-storage:client:closeStorage')
AddEventHandler('personal-storage:client:closeStorage', function()
    isStorageOpen = false
    
    -- Notification
    if Config.Framework == 'esx' then
        ESX.ShowNotification(_U('storage_closed'))
    elseif Config.Framework == 'newqb' or Config.Framework == 'oldqb' then
        QBCore.Functions.Notify(_U('storage_closed'), 'success')
    end
end)


-- E Key Interaction (if target is disabled)
if not Config.UseTarget then
    CreateThread(function()
        while true do
            local sleep = 1000
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            
            for i, storage in pairs(StoragePeds) do
                local distance = #(playerCoords - vector3(storage.coords.x, storage.coords.y, storage.coords.z))
                
                if distance < Config.InteractionDistance then
                    sleep = 0
                    
                    -- Draw 3D Text
                    DrawText3D(storage.coords.x, storage.coords.y, storage.coords.z + 2.0, _U('press_e'))
                    
                    if IsControlJustReleased(0, Config.InteractionKey) then
                        OpenStorage(i)
                    end
                end
            end
            
            Wait(sleep)
        end
    end)
end

-- Draw 3D Text Function
function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
end

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        for i, storage in pairs(StoragePeds) do
            if DoesEntityExist(storage.ped) then
                DeleteEntity(storage.ped)
            end
        end
    end
end)