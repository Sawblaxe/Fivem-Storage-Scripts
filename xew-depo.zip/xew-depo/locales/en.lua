if not Locales then Locales = {} end

Locales['en'] = {
    ['storage_opened'] = 'Storage opened',
    ['storage_closed'] = 'Storage closed',
    ['press_e'] = '[E] Open Storage',
    ['target_label'] = 'Open Storage',
    ['no_permission'] = 'You don\'t have permission to use this storage!',
    ['storage_full'] = 'Storage is full!',
    ['item_added'] = 'Item added to storage',
    ['item_removed'] = 'Item removed from storage',
    ['storage_name'] = 'Personal Storage',
    ['too_far'] = 'You are too far from the storage!',
    ['already_open'] = 'Storage is already open!',
    ['storage_error'] = 'An error occurred while opening the storage!'
}