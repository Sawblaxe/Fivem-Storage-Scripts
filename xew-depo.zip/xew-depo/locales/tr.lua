if not Locales then Locales = {} end

Locales['tr'] = {
    ['storage_opened'] = 'Depo açıldı',
    ['storage_closed'] = 'Depo kapatıldı',
    ['press_e'] = '[E] Depoyu Aç',
    ['target_label'] = 'Depoyu Aç',
    ['no_permission'] = 'Bu depoyu kullanma yetkiniz yok!',
    ['storage_full'] = 'Depo dolu!',
    ['item_added'] = 'Eşya depoya eklendi',
    ['item_removed'] = 'Eşya depodan alındı',
    ['storage_name'] = 'Kişisel Depo',
    ['too_far'] = 'Depoya çok uzaksın!',
    ['already_open'] = 'Depo zaten açık!',
    ['storage_error'] = 'Depo açılırken bir hata oluştu!'
}