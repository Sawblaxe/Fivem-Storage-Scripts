fx_version 'cerulean'
game 'gta5'

author 'Sawblaxe'
description 'Fivem Personal Storage'
version '1.0.0'
lua54 'yes'

shared_scripts {
    'config.lua',
    'locales/tr.lua',
    'locales/en.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}
