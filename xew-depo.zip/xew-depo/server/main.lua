local QBCore = nil
local ESX = nil
local Framework = nil

local Locales = Locales or {}

-- Get Locale Text
function _U(str, ...)
    if Locales[Config.Locale] ~= nil then
        if Locales[Config.Locale][str] ~= nil then
            return string.format(Locales[Config.Locale][str], ...)
        else
            return 'Translation [' .. Config.Locale .. '][' .. str .. '] does not exist'
        end
    else
        return 'Locale [' .. Config.Locale .. '] does not exist'
    end
end

-- Framework Detection
CreateThread(function()
    if Config.Framework == 'auto' then
        if GetResourceState('es_extended') == 'started' then
            Config.Framework = 'esx'
        elseif GetResourceState('qb-core') == 'started' then
            -- QB Version Detection
            local qbVersion = GetResourceMetadata('qb-core', 'version', 0)
            if qbVersion and tonumber(string.sub(qbVersion, 1, 1)) >= 2 then
                Config.Framework = 'newqb'
            else
                Config.Framework = 'oldqb'
            end
        end
    end

    -- Framework Initialize
    if Config.Framework == 'esx' then
        ESX = exports['es_extended']:getSharedObject()
        Framework = ESX
    elseif Config.Framework == 'newqb' then
        QBCore = exports['qb-core']:GetCoreObject()
        Framework = QBCore
    elseif Config.Framework == 'oldqb' then
        while QBCore == nil do
            TriggerEvent('QBCore:GetObject', function(obj) QBCore = obj end)
            Wait(200)
        end
        Framework = QBCore
    end
    
    -- Auto detect inventory system
    DetectInventorySystem()
end)

-- Inventory System Detection
function DetectInventorySystem()
    if Config.InventorySystem == 'auto' then
        if GetResourceState('ox_inventory') == 'started' then
            Config.InventorySystem = 'ox_inventory'
        elseif GetResourceState('codem-inventory') == 'started' then
            Config.InventorySystem = 'codem-inventory'
        elseif GetResourceState('tgiann-inventory') == 'started' then
            Config.InventorySystem = 'tgiann-inventory'
        elseif GetResourceState('qb-inventory') == 'started' then
            Config.InventorySystem = 'qb-inventory'
        end
    end
end

-- Get Player Function
function GetPlayer(source)
    if Config.Framework == 'esx' then
        return ESX.GetPlayerFromId(source)
    elseif Config.Framework == 'newqb' or Config.Framework == 'oldqb' then
        return QBCore.Functions.GetPlayer(source)
    end
    return nil
end

-- Get Player Identifier
function GetPlayerIdentifier(source)
    local player = GetPlayer(source)
    if not player then return nil end
    
    if Config.Framework == 'esx' then
        return player.identifier
    elseif Config.Framework == 'newqb' or Config.Framework == 'oldqb' then
        return player.PlayerData.citizenid
    end
    return nil
end

-- Register Stash Function
function RegisterStash(storageId, identifier)
    local stashName = 'personal_storage_' .. storageId .. '_' .. identifier
    
    if Config.InventorySystem == 'ox_inventory' then
        exports.ox_inventory:RegisterStash(stashName, _U('storage_name'), Config.StorageSlots, Config.StorageWeight, nil)
    elseif Config.InventorySystem == 'qb-inventory' then
        -- QB Inventory otomatik olarak stash oluşturur
    elseif Config.InventorySystem == 'codem-inventory' then
        -- Codem Inventory otomatik olarak stash oluşturur
    elseif Config.InventorySystem == 'tgiann-inventory' then
        exports['tgiann-inventory']:CreateStash(stashName, _U('storage_name'), Config.StorageSlots, Config.StorageWeight)
    end
    
    return stashName
end

-- Open Storage Event
RegisterNetEvent('personal-storage:server:openStorage')
AddEventHandler('personal-storage:server:openStorage', function(storageId, playerCoords)
    local source = source
    local player = GetPlayer(source)
    
    if not player then return end
    
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return end
    
    -- Check distance
    local storageCoords = Config.StorageLocations[storageId].coords
    local distance = #(playerCoords - vector3(storageCoords.x, storageCoords.y, storageCoords.z))
    
    if distance > Config.InteractionDistance + 1.0 then
        return -- Too far away
    end
    
    -- Register and open stash
    local stashName = RegisterStash(storageId, identifier)
    
    print('^2[Personal Storage]^7 Opening inventory: ' .. stashName .. ' for player: ' .. source)
    
    TriggerClientEvent('personal-storage:client:openInventory', source, storageId)
    
    -- Discord Log
    if Config.Discord.logStorageOpen then
        local playerName = GetPlayerName(source)
        local storageName = Config.StorageLocations[storageId].name
        local coords = Config.StorageLocations[storageId].coords
        
        local fields = {
            {
                ["name"] = "👤 Oyuncu",
                ["value"] = playerName .. " (ID: " .. source .. ")",
                ["inline"] = true
            },
            {
                ["name"] = "📦 Depo",
                ["value"] = storageName,
                ["inline"] = true
            },
            {
                ["name"] = "📍 Konum",
                ["value"] = "X: " .. math.floor(coords.x) .. " Y: " .. math.floor(coords.y) .. " Z: " .. math.floor(coords.z),
                ["inline"] = true
            },
            {
                ["name"] = "🆔 Stash ID",
                ["value"] = stashName,
                ["inline"] = false
            }
        }
        
        SendDiscordLog("📂 Depo Açıldı", playerName .. " kişisel deposunu açtı.", 3066993, fields)
    end
end)

-- Inventory Events
if Config.InventorySystem == 'qb-inventory' then
    -- QB Inventory için özel event handler kaldırıldı (çakışma önlemi)
end

-- Storage close event
RegisterNetEvent('personal-storage:server:closeStorage')
AddEventHandler('personal-storage:server:closeStorage', function(storageId)
    local source = source
    
    -- Discord Log
    if Config.Discord.logStorageClose then
        local playerName = GetPlayerName(source)
        local storageName = storageId and Config.StorageLocations[storageId] and Config.StorageLocations[storageId].name or "Bilinmeyen Depo"
        
        local fields = {
            {
                ["name"] = "👤 Oyuncu",
                ["value"] = playerName .. " (ID: " .. source .. ")",
                ["inline"] = true
            },
            {
                ["name"] = "📦 Depo",
                ["value"] = storageName,
                ["inline"] = true
            }
        }
        
        SendDiscordLog("📁 Depo Kapatıldı", playerName .. " kişisel deposunu kapattı.", 15158332, fields)
    end
    
    TriggerClientEvent('personal-storage:client:closeStorage', source)
end)

-- Item Transfer Logging (OX Inventory)
if Config.InventorySystem == 'ox_inventory' then
    AddEventHandler('ox_inventory:swappedItem', function(source, fromInventory, toInventory, fromSlot, toSlot, fromItem, toItem)
        if not Config.Discord.logItemTransfer then return end
        
        local playerName = GetPlayerName(source)
        
        -- Check if it's a storage transfer
        if string.find(fromInventory, 'personal_storage_') or string.find(toInventory, 'personal_storage_') then
            local action = ""
            local itemInfo = ""
            
            if string.find(toInventory, 'personal_storage_') then
                -- Item added to storage
                action = "📥 Depoya Eklendi"
                itemInfo = fromItem.label .. " x" .. fromItem.count
            elseif string.find(fromInventory, 'personal_storage_') then
                -- Item removed from storage
                action = "📤 Depodan Alındı"
                itemInfo = fromItem.label .. " x" .. fromItem.count
            end
            
            if action ~= "" then
                local fields = {
                    {
                        ["name"] = "👤 Oyuncu",
                        ["value"] = playerName .. " (ID: " .. source .. ")",
                        ["inline"] = true
                    },
                    {
                        ["name"] = "📦 Eşya",
                        ["value"] = itemInfo,
                        ["inline"] = true
                    },
                    {
                        ["name"] = "🔄 İşlem",
                        ["value"] = action,
                        ["inline"] = true
                    }
                }
                
                local color = string.find(toInventory, 'personal_storage_') and 65280 or 16711680 -- Green for add, Red for remove
                SendDiscordLog(action, playerName .. " depo işlemi gerçekleştirdi.", color, fields)
            end
        end
    end)
end

-- Item Transfer Logging (QB Inventory)
if Config.InventorySystem == 'qb-inventory' then
    -- QB Inventory item move event
    RegisterNetEvent('inventory:server:SaveInventory')
    AddEventHandler('inventory:server:SaveInventory', function(type, id)
        if not Config.Discord.logItemTransfer then return end
        
        local source = source
        if string.find(id, 'personal_storage_') then
            local playerName = GetPlayerName(source)
            
            local fields = {
                {
                    ["name"] = "👤 Oyuncu",
                    ["value"] = playerName .. " (ID: " .. source .. ")",
                    ["inline"] = true
                },
                {
                    ["name"] = "📦 Depo",
                    ["value"] = id,
                    ["inline"] = true
                }
            }
            
            SendDiscordLog("🔄 Depo Güncellendi", playerName .. " depo içeriğini değiştirdi.", 16776960, fields)
        end
    end)
    
    -- QB Inventory detailed item logging
    RegisterNetEvent('inventory:server:SetInventoryData')
    AddEventHandler('inventory:server:SetInventoryData', function(fromInventory, toInventory, item)
        if not Config.Discord.logItemTransfer then return end
        
        local source = source
        local playerName = GetPlayerName(source)
        
        if string.find(fromInventory, 'personal_storage_') or string.find(toInventory, 'personal_storage_') then
            local action = ""
            local itemInfo = item.label .. " x" .. item.amount
            
            if string.find(toInventory, 'personal_storage_') then
                action = "📥 Depoya Eklendi"
            elseif string.find(fromInventory, 'personal_storage_') then
                action = "📤 Depodan Alındı"
            end
            
            if action ~= "" then
                local fields = {
                    {
                        ["name"] = "👤 Oyuncu",
                        ["value"] = playerName .. " (ID: " .. source .. ")",
                        ["inline"] = true
                    },
                    {
                        ["name"] = "📦 Eşya",
                        ["value"] = itemInfo,
                        ["inline"] = true
                    },
                    {
                        ["name"] = "🔄 İşlem",
                        ["value"] = action,
                        ["inline"] = true
                    }
                }
                
                local color = string.find(toInventory, 'personal_storage_') and 65280 or 16711680
                SendDiscordLog(action, playerName .. " depo işlemi gerçekleştirdi.", color, fields)
            end
        end
    end)
end

-- Item Transfer Logging (Codem Inventory)
if Config.InventorySystem == 'codem-inventory' then
    RegisterNetEvent('codem-inventory:server:itemMoved')
    AddEventHandler('codem-inventory:server:itemMoved', function(fromInventory, toInventory, item)
        if not Config.Discord.logItemTransfer then return end
        
        local source = source
        local playerName = GetPlayerName(source)
        
        if string.find(fromInventory, 'personal_storage_') or string.find(toInventory, 'personal_storage_') then
            local action = ""
            local itemInfo = item.label .. " x" .. item.count
            
            if string.find(toInventory, 'personal_storage_') then
                action = "📥 Depoya Eklendi"
            elseif string.find(fromInventory, 'personal_storage_') then
                action = "📤 Depodan Alındı"
            end
            
            if action ~= "" then
                local fields = {
                    {
                        ["name"] = "👤 Oyuncu",
                        ["value"] = playerName .. " (ID: " .. source .. ")",
                        ["inline"] = true
                    },
                    {
                        ["name"] = "📦 Eşya",
                        ["value"] = itemInfo,
                        ["inline"] = true
                    },
                    {
                        ["name"] = "🔄 İşlem",
                        ["value"] = action,
                        ["inline"] = true
                    }
                }
                
                local color = string.find(toInventory, 'personal_storage_') and 65280 or 16711680
                SendDiscordLog(action, playerName .. " depo işlemi gerçekleştirdi.", color, fields)
            end
        end
    end)
end

-- Item Transfer Logging (TGiann Inventory)
if Config.InventorySystem == 'tgiann-inventory' then
    RegisterNetEvent('tgiann-inventory:server:itemTransfer')
    AddEventHandler('tgiann-inventory:server:itemTransfer', function(fromInventory, toInventory, item)
        if not Config.Discord.logItemTransfer then return end
        
        local source = source
        local playerName = GetPlayerName(source)
        
        if string.find(fromInventory, 'personal_storage_') or string.find(toInventory, 'personal_storage_') then
            local action = ""
            local itemInfo = item.label .. " x" .. item.count
            
            if string.find(toInventory, 'personal_storage_') then
                action = "📥 Depoya Eklendi"
            elseif string.find(fromInventory, 'personal_storage_') then
                action = "📤 Depodan Alındı"
            end
            
            if action ~= "" then
                local fields = {
                    {
                        ["name"] = "👤 Oyuncu",
                        ["value"] = playerName .. " (ID: " .. source .. ")",
                        ["inline"] = true
                    },
                    {
                        ["name"] = "📦 Eşya",
                        ["value"] = itemInfo,
                        ["inline"] = true
                    },
                    {
                        ["name"] = "🔄 İşlem",
                        ["value"] = action,
                        ["inline"] = true
                    }
                }
                
                local color = string.find(toInventory, 'personal_storage_') and 65280 or 16711680
                SendDiscordLog(action, playerName .. " depo işlemi gerçekleştirdi.", color, fields)
            end
        end
    end)
    
    -- TGiann generic inventory update
    RegisterNetEvent('tgiann-inventory:server:updateInventory')
    AddEventHandler('tgiann-inventory:server:updateInventory', function(inventoryId)
        if not Config.Discord.logItemTransfer then return end
        
        local source = source
        if string.find(inventoryId, 'personal_storage_') then
            local playerName = GetPlayerName(source)
            
            local fields = {
                {
                    ["name"] = "👤 Oyuncu",
                    ["value"] = playerName .. " (ID: " .. source .. ")",
                    ["inline"] = true
                },
                {
                    ["name"] = "📦 Depo",
                    ["value"] = inventoryId,
                    ["inline"] = true
                }
            }
            
            SendDiscordLog("🔄 Depo Güncellendi", playerName .. " depo içeriğini değiştirdi.", 16776960, fields)
        end
    end)
end

-- Generic Item Transfer Logging (Fallback for unknown systems)
RegisterNetEvent('personal-storage:server:logItemTransfer')
AddEventHandler('personal-storage:server:logItemTransfer', function(action, itemName, itemCount, storageId)
    if not Config.Discord.logItemTransfer then return end
    
    local source = source
    local playerName = GetPlayerName(source)
    local storageName = Config.StorageLocations[storageId] and Config.StorageLocations[storageId].name or "Bilinmeyen Depo"
    
    local actionText = ""
    local color = 16776960
    
    if action == "add" then
        actionText = "📥 Depoya Eklendi"
        color = 65280 -- Green
    elseif action == "remove" then
        actionText = "📤 Depodan Alındı"
        color = 16711680 -- Red
    end
    
    local fields = {
        {
            ["name"] = "👤 Oyuncu",
            ["value"] = playerName .. " (ID: " .. source .. ")",
            ["inline"] = true
        },
        {
            ["name"] = "📦 Eşya",
            ["value"] = itemName .. " x" .. itemCount,
            ["inline"] = true
        },
        {
            ["name"] = "🏪 Depo",
            ["value"] = storageName,
            ["inline"] = true
        }
    }
    
    SendDiscordLog(actionText, playerName .. " depo işlemi gerçekleştirdi.", color, fields)
end)

print('^2[Personal Storage]^7 Script başarıyla yüklendi!')
print('^2[Personal Storage]^7 Framework: ^3' .. Config.Framework)
print('^2[Personal Storage]^7 Inventory System: ^3' .. Config.InventorySystem)
print('^2[Personal Storage]^7 Target System: ^3' .. (Config.UseTarget and Config.TargetSystem or 'Disabled'))
print('^2[Personal Storage]^7 Language: ^3' .. Config.Locale)
print('^2[Personal Storage]^7 Ped Model: ^3' .. Config.PedModel)
print('^2[Personal Storage]^7 Storage Locations: ^3' .. #Config.StorageLocations)

-- Discord Webhook Function
function SendDiscordLog(title, description, color, fields)
    if not Config.Discord.enabled then return end
    
    local embed = {
        {
            ["title"] = title,
            ["description"] = description,
            ["type"] = "rich",
            ["color"] = color or Config.Discord.color,
            ["fields"] = fields or {},
            ["footer"] = {
                ["text"] = "Kişisel Depo Sistemi • " .. os.date("%d/%m/%Y %H:%M:%S"),
            },
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }
    }
    
    local data = {
        ["username"] = Config.Discord.botName,
        ["avatar_url"] = Config.Discord.avatar,
        ["embeds"] = embed
    }
    
    PerformHttpRequest(Config.Discord.webhook, function(err, text, headers) end, 'POST', json.encode(data), { ['Content-Type'] = 'application/json' })
end

-- Get Player Name Function
function GetPlayerName(source)
    local player = GetPlayer(source)
    if not player then return "Bilinmeyen Oyuncu" end
    
    if Config.Framework == 'esx' then
        return player.getName()
    elseif Config.Framework == 'newqb' or Config.Framework == 'oldqb' then
        return player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
    end
    return GetPlayerName(source)
end